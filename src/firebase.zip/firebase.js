/* eslint-disable */
import firebase from 'firebase'
import 'firebase/performance'

let config = {
  apiKey: "AIzaSyBTANNXKcYLbADitMbncFmQP68697ye2SU",
  authDomain: "cetakid-landing-page.firebaseapp.com",
  databaseURL: "https://cetakid-landing-page.firebaseio.com",
  projectId: "cetakid-landing-page",
  storageBucket: "cetakid-landing-page.appspot.com",
  messagingSenderId: "306439557812",
  appId: "1:306439557812:web:7df2a02839c4dc03"
}

let app = firebase.initializeApp(config)
let db = app.database()

let subscribeRef = db.ref('subscribe')

export default subscribeRef